import { useLanguage } from '../contexts/LanguageContext';

const translations = {
  ar: {
    // Navigation
    home: 'الرئيسية',
    about: 'عن المشروع',
    submit: 'قدّم نصّك',
    contact: 'تواصل',
    
    // Hero Section
    projectName: 'الدُرج',
    slogan: 'من الدُرج للخشبة',
    heroDescription: 'منصة لنشر وأرشفة النصوص المسرحية غير المنشورة للكتّاب المصريين الشباب',
    submitScript: 'قدّم نصّك',
    learnMore: 'اعرف أكثر',
    
    // About Section
    aboutTitle: 'عن الدُرج',
    aboutDescription: 'الدُرج هو مساحة رقمية مخصصة لدعم المواهب الشابة في مجال الكتابة المسرحية. نهدف إلى توفير منصة لنشر وأرشفة النصوص المسرحية غير المنشورة، مما يساعد على الحفاظ على التراث المسرحي المعاصر وإتاحة الفرصة للمبدعين الشباب لعرض أعمالهم والوصول إلى جمهور أوسع.',
    ourMission: 'رسالتنا',
    missionDescription: 'نؤمن بأن المسرح هو مرآة المجتمع وصوت الأجيال. من خلال الدُرج، نسعى لخلق جسر بين الكتّاب الشباب والمخرجين والجمهور المهتم بالفن المسرحي.',
    
    // Footer
    allRightsReserved: 'جميع الحقوق محفوظة',
    followUs: 'تابعنا',
    quickLinks: 'روابط سريعة',
  },
  en: {
    // Navigation
    home: 'Home',
    about: 'About',
    submit: 'Submit',
    contact: 'Contact',
    
    // Hero Section
    projectName: 'Al-Dorag',
    slogan: 'From the Drawer to the Stage',
    heroDescription: 'A platform to publish and archive unpublished theatrical scripts by young Egyptian playwrights',
    submitScript: 'Submit Your Script',
    learnMore: 'Learn More',
    
    // About Section
    aboutTitle: 'About Al-Dorag',
    aboutDescription: 'Al-Dorag is a digital space dedicated to supporting young talents in theatrical writing. We aim to provide a platform for publishing and archiving unpublished theatrical scripts, helping preserve contemporary theatrical heritage and giving young creators the opportunity to showcase their work to a wider audience.',
    ourMission: 'Our Mission',
    missionDescription: 'We believe that theater is the mirror of society and the voice of generations. Through Al-Dorag, we seek to create a bridge between young writers, directors, and audiences interested in theatrical art.',
    
    // Footer
    allRightsReserved: 'All Rights Reserved',
    followUs: 'Follow Us',
    quickLinks: 'Quick Links',
  }
};

export const useTranslation = () => {
  const { language } = useLanguage();
  
  const t = (key: keyof typeof translations.ar): string => {
    return translations[language][key] || key;
  };
  
  return { t };
};